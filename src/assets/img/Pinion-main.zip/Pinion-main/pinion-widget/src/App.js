import { PinionWidget } from "./pinion-widget";

function App() {
  return (
    <div className="App container mx-auto">
        <PinionWidget source="/test"/>
    </div>
  );
}

export default App;
