# Pinion Widget

This package is a fontend for [Pinion](https://github.com/yaqwsx/Pinion/) - a
tool for creating nice-looking interactive pinout diagrams for PCBs designed in
KiCAD.